#!/usr/bin/env bash
set -e
OUTDIR="./dashboard_offline"
HTML_SOURCE="controle_financeiro_mensal_lucas_fixed.html"
if [ ! -f "$HTML_SOURCE" ]; then
  echo "Coloque $HTML_SOURCE na pasta atual e reexecute."
  exit 1
fi
mkdir -p "$OUTDIR/libs"
cp "$HTML_SOURCE" "$OUTDIR/"
echo "Baixando bibliotecas..."
curl -L -o "$OUTDIR/libs/xlsx.full.min.js" https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js
curl -L -o "$OUTDIR/libs/chart.umd.min.js" https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js
curl -L -o "$OUTDIR/libs/jszip.min.js" https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js
# substitua as tags CDN no HTML por ./libs/ (simples replace)
sed -i.bak 's@https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js@./libs/xlsx.full.min.js@g' "$OUTDIR/$HTML_SOURCE"
sed -i.bak 's@https://cdn.jsdelivr.net/npm/chart.js@./libs/chart.umd.min.js@g' "$OUTDIR/$HTML_SOURCE"
sed -i.bak 's@https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js@./libs/jszip.min.js@g' "$OUTDIR/$HTML_SOURCE"
echo "Criando ZIP offline..."
(cd "$OUTDIR" && zip -r "../controle_financeiro_mensal_lucas_offline.zip" .)
echo "Feito: controle_financeiro_mensal_lucas_offline.zip"
