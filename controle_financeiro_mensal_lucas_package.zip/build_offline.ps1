$out = ".\dashboard_offline"; if(-Not (Test-Path $out)){ New-Item -ItemType Directory -Force -Path $out } Copy-Item ".\controle_financeiro_mensal_lucas_fixed.html" $out -Force; New-Item -ItemType Directory -Force -Path "$out\libs" | Out-Null
Write-Host "Baixando bibliotecas..."
Invoke-WebRequest "https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js" -OutFile "$out\libs\xlsx.full.min.js"
Invoke-WebRequest "https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js" -OutFile "$out\libs\chart.umd.min.js"
Invoke-WebRequest "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js" -OutFile "$out\libs\jszip.min.js"
Write-Host "Substitua manualmente as tags CDN por ./libs/ no arquivo HTML se necessário."
Compress-Archive -Path "$out\*" -DestinationPath "controle_financeiro_mensal_lucas_offline.zip" -Force
Write-Host "Feito: controle_financeiro_mensal_lucas_offline.zip"
