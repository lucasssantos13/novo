# Controle Financeiro Mensal — Lucas O. dos Santos

Arquivos incluídos:
- controle_financeiro_mensal_lucas_fixed.html  (HTML do dashboard)
- build_offline.sh  (script Linux/macOS para baixar libs e gerar pacote offline)
- build_offline.ps1 (script PowerShell para Windows)

INSTRUÇÕES RÁPIDAS:
1. Abra `controle_financeiro_mensal_lucas_fixed.html` no navegador (Chrome/Edge/Firefox).
2. Clique em **Escolher arquivo** e selecione sua planilha .xls/.xlsx/.xlsm.
3. Para criar versão 100% offline (sem CDN): execute `build_offline.sh` (Linux/macOS) ou `build_offline.ps1` (Windows) — ele baixará as libs em ./libs e criará um ZIP offline.